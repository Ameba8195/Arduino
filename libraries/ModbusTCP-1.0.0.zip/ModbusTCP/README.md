ModbusTCP
=========

A Modbus TCP class for Arduino and either Ethernet or Adafruit CC3000 WiFi shield that includes support for 32-bit integer and float operations.

If you're using an ESP8266 device check this post: https://forums.adafruit.com/viewtopic.php?f=31&t=61774&start=15
